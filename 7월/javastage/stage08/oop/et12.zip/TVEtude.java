package stage08.oop.et12;

public class TVEtude {
  public static void main(String[] args) {
    TV tv = new LgTV();
    tv.powerOn();
    tv.channelUp();
    tv.channelUp();
    tv.soundUp();
    tv.powerOff();
  }
}
